#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_CONFIGURENOISEGATE                  101
#define IDC_ENABLEGATE                          1001
#define IDC_CURVOL                              1007
#define IDC_PREVIEWON                           1010
#define IDC_CLOSETHRES_SLIDER                   1018
#define IDC_OPENTHRES_SLIDER                    1019
#define IDC_RELEASETIME_EDIT                    1024
#define IDC_HOLDTIME_EDIT                       1025
#define IDC_ATTACKTIME_EDIT                     1026
#define IDC_OPENTHRES_DB                        1028
#define IDC_CLOSETHRES_DB                       1029
