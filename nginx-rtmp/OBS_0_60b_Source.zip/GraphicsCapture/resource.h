//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GraphicsCapture.rc
//
#define IDD_CONFIG                      101
#define IDC_COMBO1                      1001
#define IDC_APPLIST                     1001
#define IDC_REFRESH                     1002
#define IDC_STRETCHTOSCREEN             1003
#define IDC_CAPTUREMOUSE                1004
#define IDC_INVERTMOUSEONCLICK          1005
#define IDC_INFO                        1006
#define IDC_STRETCHTOSCREEN2            1007
#define IDC_IGNOREASPECT                1007
#define IDC_SELECTAPP                   1008
#define IDC_USEHOTKEY                   1009
#define IDC_BUTTON1                     1010
#define IDC_CLEARHOTKEY                 1010
#define IDC_GAMMA                       1035
#define IDC_STARTSTREAMHOTKEY           1097
#define IDC_HOTKEY                      1097
#define IDC_GAMMAVAL                    1151

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
