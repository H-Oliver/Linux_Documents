//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DShowPlugin.rc
//
#define IDD_CONFIG                      101
#define IDC_DEVICELIST                  1001
#define IDC_CONFIG                      1002
#define IDC_AUDIOLIST                   1003
#define IDC_CONFIGAUDIO                 1004
#define IDC_DEINTERLACELIST             1005
#define IDC_CROSSBAR                    1007
#define IDC_RESOLUTION                  1008
#define IDC_FPS_EDIT                    1009
#define IDC_FPS                         1010
#define IDC_REFRESH                     1011
#define IDC_FPS2                        1012
#define IDC_USEPREFERREDOUTPUT          1012
#define IDC_USEPREFERREDOUTPUT2         1013
#define IDC_USEBUFFERING                1013
#define IDC_FLIPIMAGE                   1014
#define IDC_BUTTON1                     1015
#define IDC_CUSTOM                      1015
#define IDC_SELECTCOLOR                 1015
#define IDC_COLORPICKET                 1015
#define IDC_COLORPICKER                 1015
#define IDC_AUTOMATICRESOLUTION         1016
#define IDC_CUSTOMRESOLUTION            1016
#define IDC_USECHROMAKEY                1017
#define IDC_USECOLORKEY                 1017
#define IDC_COLOR                       1018
#define IDC_BASETHRESHOLD               1019
#define IDC_BASETHRESHOLD_EDIT          1020
#define IDC_BASETHRESHOLD_CHI           1021
#define IDC_BLEND_EDIT                  1021
#define IDC_BLEND                       1022
#define IDC_GAMMA_EDIT                  1023
#define IDC_SPILLREDUCTION_EDIT         1023
#define IDC_SPILLREDUCTION              1024
#define IDC_FLIPIMAGEH                  1025
#define IDC_PREFERREDOUTPUT             1026
#define IDC_OPACITY_EDIT                1027
#define IDC_OPACITY                     1028
#define IDC_OUTPUTSOUND                 1029
#define IDC_PLAYDESKTOPSOUND            1030
#define IDC_EDIT1                       1032
#define IDC_TIMEOFFSET_EDIT             1032
#define IDC_TIMEOFFSET                  1033
#define IDC_CHECK1                      1034
#define IDC_TFF                         1034
#define IDC_VOLUME                      1035
#define IDC_VOLMETER                    1036
#define IDC_POINTFILTERING              1036
#define IDC_DELAY_EDIT                  1037
#define IDC_VIDEODELAY                  1038
#define IDC_DELAY                       1038
#define IDC_GAMMA                       1039
#define IDC_BFF                         1040
#define IDC_GPUDEINT                    1041
#define IDC_PRESERVESIZE                1042
#define IDC_64BIT_WARNING               1043
#define IDC_USEAUDIORENDER              1044
#define IDC_GAMMAVAL                    1151

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1044
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
